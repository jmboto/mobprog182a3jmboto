package com.example.convertmilestokilometer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonConvMILEStoKILOMETERS = (Button) findViewById(R.id.buttonConvMILEStoKILOMETERS);
        buttonConvMILEStoKILOMETERS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textBoxMILES = (EditText) findViewById(R.id.editTextMILES);
                EditText textBoxKILOMETERS = (EditText) findViewById(R.id.editTextMILES3);
                double vMILES = Double.valueOf(textBoxMILES.getText().toString());
                double vKILOMETERS = vMILES / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxKILOMETERS.setText(formatVal.format(vKILOMETERS));

            }
        });
        Button buttonConvKILOMETERStoMILES = (Button) findViewById(R.id.buttonConvKILOMETERStoMILES);
        buttonConvKILOMETERStoMILES.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textBoxMILES = (EditText) findViewById(R.id.editTextMILES);
                EditText textBoxKILOMETERS = (EditText) findViewById(R.id.editTextMILES3);
                double vKILOMETERS = Double.valueOf(textBoxKILOMETERS.getText().toString());
                double vMILES = vKILOMETERS * 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxMILES.setText(formatVal.format(vMILES));

            }
        });
    }
}
